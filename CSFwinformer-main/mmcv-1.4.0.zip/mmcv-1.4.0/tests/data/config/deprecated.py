_base_ = './expected.py'

_deprecation_ = dict(
    expected='tests/data/config/expected.py',
    reference='https://github.com/open-mmlab/mmcv/pull/1275')
