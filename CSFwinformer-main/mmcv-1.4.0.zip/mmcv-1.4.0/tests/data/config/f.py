_base_ = './d.py'
item4 = 'test_recursive_bases'
